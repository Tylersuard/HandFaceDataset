
cv - v7 FaceHandDataset
==============================

This dataset was exported via roboflow.ai on July 25, 2020 at 4:39 AM GMT

It includes 572 images.
Face-hand are annotated in COCO format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


