
cv - v7 FaceHandDataset
==============================

This dataset was exported via roboflow.ai on July 25, 2020 at 4:38 AM GMT

It includes 572 images.
Face-hand are annotated in Tensorflow Object Detection format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


